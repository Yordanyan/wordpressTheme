///Add Plugins
Add Smart Slider
Add WP Forms
